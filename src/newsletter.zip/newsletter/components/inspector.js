const { __ } = wp.i18n;
const { Component } = wp.element;
const { InspectorControls, PanelColorSettings } = wp.editor;
const { TextControl, PanelBody,SelectControl } = wp.components;

export default class Inspector extends Component {
	state = {
		mc_list_options: [],
	}

	onUpdateApiKey = (key) => {
		let mc_lists =[];
		fetch( ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body:"action=pb_mailchimp_block_save_key&api_key="+key
		}).then( ( response ) => {
			return response.json();
		}).then( ( json ) => {
			console.log(json);
			if ( json.success ) {
				let data = JSON.parse(json.data);
				if( data.lists.length == 0) {
					mc_lists.push( { value:0,label: __( 'No Lists Found - Check API Key' ) } );
					this.setState( ( state, props ) => ( {
						mc_list_options: mc_lists,
					} ) )
	
					this.props.setAttributes({
						mailchimp_list: mc_lists
					});
				} else {
				
					for (var key in data.lists) {
						if (data.lists.hasOwnProperty(key)) {
							mc_lists.push({value: data.lists[key].id, label: data.lists[key].name});
						}
					}
					this.setState( ( state, props ) => ( {
						mc_list_options: mc_lists,
					} ) )

					this.props.setAttributes({
						mailchimp_list: mc_lists
					});
				}
			} else {
				
				mc_lists.push( { value:0, label: __( 'No Lists Found or Invalid API key') } );
				
				this.setState( ( state, props ) => ( {
					mc_list_options: mc_lists,
				} ) )

				this.props.setAttributes({
					mailchimp_list: mc_lists
				});
			}

		});

	}

    updateList = (list) => {
        fetch(ajaxurl, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body:"action=pb_mailchimp_block_save_list&list="+list
        });
    }

    componentDidMount () {
    	console.log('haha componentDid Mount');
		console.log(pb_mailchimp_block.mailchimp_lists);

    	this.props.setAttributes({
    		apiKey : pb_mailchimp_block.api_key,
    		mailchimp_list: pb_mailchimp_block.mailchimp_list
    	});
    	let mc_lists =[];
    	let data = pb_mailchimp_block.mailchimp_lists;
		for (var key in data) {
			if (data.hasOwnProperty(key)) {
				mc_lists.push({value: data[key].id, label: data[key].name});
			}
		}
		console.log(mc_lists);

		this.setState( ( state, props ) => ( {
			mc_list_options: mc_lists
		} ) )

    	// this.setState({
    	// 	mc_list_options : pb_mailchimp_block.mailchimp_lists
    	// })
    }

	render() {
		const {
			attributes: {
				emailFieldLabel,
				nameFieldLabel,
				submitFieldLabel,
				successMessage,
				errorMessage,
				submitMessage,
				duplicateMessage,
				apiKey,
				submitButtonTextColor,
				submitButtonBackgroundColor,
				newsletterbackgroundColor,
				mailchimp_list,
			},
			setAttributes,
			state,
		} = this.props;

		// console.log('haha');
		// console.log(pb_mailchimp_block.api_key);
		// console.log('haha lists');
		// console.log(pb_mailchimp_block.mailchimp_lists);
		// console.log('haha list');
		// console.log(pb_mailchimp_block.mailchimp_list);

		// let data = JSON.parse(pb_mailchimp_block.mailchimp_lists);

		// for (var key in data.lists) {
		// 	if (data.lists.hasOwnProperty(key)) {
		// 		mc_list.push({value: data.lists[key].id, label: data.lists[key].name});
		// 	}
		// }

		// this.setState( ( state, props ) => ( {
		// 	list_options: mc_list
		// } ) )

		// console.log("parse from option");

		// console.log(this.state.list_options);
		//

		const Colors = [
				{ color: '#F78DA7', name: __( 'GPB Color' ) },
				{ color: '#CF2E2E', name: __( 'Prunus Avium' ) },
				{ color: '#FF6903', name: __( 'Chi-gong' ) },
				{ color: '#FCB902', name: __( 'Pico-8' ) },
				{ color: '#7BDCB5', name: __( 'Robin\'s Egg Blue' ) },
				{ color: '#FE4A5A', name: __( 'Orange Ville' ) },
				{ color: '#24C030', name: __( 'Bright Yarrow' ) },
				{ color: '#4BBDFF', name: __( 'Light Greenish Blue' ) },
				{ color: '#9013FE', name: __( 'Mint Leaf' ) },
				{ color: '#4C84FF', name: __( 'Exodus Fruit' ) },
				{ color: '#BD10E0', name: __( 'Sour Lemon' ) },
				{ color: '#F0F0F0', name: __( 'First Date' ) },
				{ color: '#000000', name: __( 'Green Darnet Tail' ) },
		];

		return (

			<div>
				<InspectorControls>
					<PanelBody>
						<TextControl
							label={ '' + pb_mailchimp_block.api_key }
							value={ apiKey }
							onChange={ ( value ) => {
								setAttributes( { apiKey: value } )
                            	this.onUpdateApiKey( value );
							} }
						/>
						<SelectControl className="pb-mailchimp-lists"
							label={ 'List' }
							value={ mailchimp_list }
							options={ this.state.mc_list_options }
							onChange={ (value) => {
								setAttributes({
									mailchimp_list: value
								});
								this.updateList( value );
							} }
						/>



						<TextControl
							label={ __( 'Email Field Label' ) }
							value={ emailFieldLabel }
							onChange={ ( value ) => setAttributes( { emailFieldLabel: value } ) }
						/>
						<TextControl
							label={ __( 'Name Field Label' ) }
							value={ nameFieldLabel }
							onChange={ ( value ) => setAttributes( { nameFieldLabel: value } ) }
						/>
						<TextControl
							label={ __( 'Submit Button Label' ) }
							value={ submitFieldLabel }
							onChange={ ( value ) => setAttributes( { submitFieldLabel: value } ) }
						/>
						<TextControl
							label={ __( 'Success Message') }
							value={ successMessage }
							onChange={ ( value ) => setAttributes( { successMessage: value } ) }
						/>
						<TextControl
							label={ __( 'Submit Message') }
							value={ submitMessage }
							onChange={ ( value ) => setAttributes( { submitMessage: value } ) }
						/>
						<TextControl
							label={ __( 'Error Message') }
							value={ errorMessage }
							onChange={ ( value ) => setAttributes( { errorMessage: value } ) }
						/>
						<TextControl
							label={ __( 'Duplicate Message' ) }
							value={ duplicateMessage }
							onChange={ ( value ) => setAttributes( { duplicateMessage: value } ) }
						/>

						<PanelColorSettings
							title={ __( 'Color Settings' ) }
							initialOpen={ false }
							colorSettings={ [
								{
									value: submitButtonTextColor,
									onChange: value => setAttributes( { submitButtonTextColor: value } ),
									label: __( 'Button Text Color' ),
									colors: Colors,
								},
								{
									value: submitButtonBackgroundColor,
									onChange: value => setAttributes( { submitButtonBackgroundColor: value } ),
									label: __( 'Button Background Color' ),
									colors: Colors,
								},
								{
									value: newsletterbackgroundColor,
									onChange: value => setAttributes( { newsletterbackgroundColor: value } ),
									label: __( 'Background Color' ),
									colors: Colors,
								},
							] }
						/>
					</PanelBody>
				</InspectorControls>
			</div>
		);
	}
}
