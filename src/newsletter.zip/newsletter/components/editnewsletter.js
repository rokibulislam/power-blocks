const { Component, Fragment } = wp.element;
const { AlignmentToolbar, BlockControls } = wp.editor;
import Inspector from './inspector';
import Newsletter from './newsletter'
export default class EditNewsletter extends Component {
	state = {
			apiKey: '',
			hasError:  false,
			isLoading: true,
			isSavedKey: true,
			isSaving: false,
			keySaved: false,
		}
	constructor( props ) {
		super( ...arguments );
	}

	render() {
		const {
			attributes: {

			},
			setAttributes,
			isSelected,
			className
		} = this.props;
		return (
			<Fragment>
				<BlockControls key="controls">
					<AlignmentToolbar
						value={ '' }
						onChange={ ( value ) => setAttributes( { 'newsletteralignment': value } ) }
					/>
				</BlockControls>
				<Inspector { ...{ setAttributes, ...this.props } } state={ this.state }/>
				<Newsletter { ...this.props } key="" state={ this.state }></Newsletter>
			</Fragment>
		);
	}
}
