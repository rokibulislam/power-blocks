<Placeholder
	label={  __( 'MailChimp' ) }
	instructions={ ( 'Enter Your MailChimp Api Key' ) }
>

	<TextControl
		className="components-placeholder__input"
		// value={ this.state.apiKey }
		// onChange={ value => this.setState( { apiKey: value } ) }
		placeholder={ __( 'Enter Google API key…' ) }
		// style={ ( this.state.hasError ) ? { border: '1px solid red' } : null }
	/>

	<Button
		isLarge
		type="button"
		// onClick={ () => renderMap() }
	>
		{ __( 'Apply' ) }
	</Button>

</Placeholder>


<label> { ( nameFieldLabel ) ? nameFieldLabel : 'Name:' } </label>
<label> { ( emailFieldLabel ) ? emailFieldLabel : 'Email:' } </label>