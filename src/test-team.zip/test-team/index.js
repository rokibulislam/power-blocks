import classnames from 'classnames';
//  Import CSS.
import "./styles/style.scss";
import "./styles/editor.scss";
const __ = wp.i18n.__; // The __() for internationalization.
const registerBlockType = wp.blocks.registerBlockType; // The registerBlockType() to register blocks.
// const { RichText, PlainText } = wp.editor;
const { PanelColorSettings, InspectorControls, RichText,PlainText } = wp.editor;
const { PanelBody, RangeControl, ToggleControl, SelectControl, TextControl, RadioControl } = wp.components;
import Edit from './edit';
import TeamMember from './teamMember';
registerBlockType( 'power-blocks/team-member', {
	title: __( 'Team Member', 'power-blocks' ),
	description: __( '.', 'power-blocks' ),
	icon: 'format-status',
	category: 'power-blocks', 
	keywords: [
		__( 'Team Member', 'power-blocks' ),
	],
	attributes: {
		teams: {
			type: "array",
			// source: "query",
			default: [],
			// selector: "div.pb_team",
			// query: {
			// 	index: {
			// 		type: "string",
			// 		source: "text",
			// 		selector: "span.team-index"
			// 	},
			// 	image: {
			// 		type: 'string',
			// 		source: "attribute",
			// 		selector: "img.pb-team-member-image",
			// 		attribute: "src"
			// 	},
				
			// 	memberName: {
			// 		type: "string",
			// 		source: "text",
			// 		selector: "h2.pb-team-member-name"
            //     },
            //     memberNameColor: {
            //         type: 'string',
            //         default: '#fff',
            //     },
            //     memberNameFontSize: {
            //         type: 'number',
            //         default: 24,
            //     },
			// 	memberDesignation: {
			// 		type: "string",
			// 		source: "text",
			// 		selector: "p.pb-team-member-description"
            //     },
            //     memberDesignationColor: {
            //         type: 'string',
            //         default: '#fff',
            //     },
            //     memberDesignationFontSize: {
            //         type: 'number',
            //         default: 15,
            //     },
			// 	memberDescription: {
			// 		type: "string",
			// 		source: "text",
			// 		selector: "p.pb-team-member-designation"
            //     },
            //     memberDescriptionFontSize: {
            //         type: 'number',
            //         default: 15,
            //     },
            //     memberDescriptionColor: {
            //         type: 'string',
            //         default: '#fff',
            //     },
            //     memberAlignment: {
            //         type: 'string',
            //         default: 'left',
            //     },
            //     memberBackgroundColor: {
			// 		type: 'string',
			// 		// attribute: 'style',
			// 		// selector: 'div.pb-team-member-background',
			// 		default: '#0073a8',
			// 		// property: 'background-color'
			// 	},
			// 	memberboxshadow: {
			// 		type: 'number',
			// 		default: 0,
			// 	},
			// 	memberBorderRadius: {
			// 		type: 'number',
			// 		default: 0,
			// 	},
			// 	memberMargin: {
			// 		type: 'number',
			// 		default: 0,
			// 	},
			// 	memberPadding: {
			// 		type: 'number',
			// 		default: 0,
			// 	},
			// 	memberImageStyle: {
			// 		type: 'string',
			// 		default: 'round',
			// 	},
			
			// 	socialIconWidth: {
			// 		type: 'number',
			// 		default: 32,
			// 	},
			
			// 	socialIconHeight: {
			// 		type: 'number',
			// 		default: 32,
			// 	},
			
			// 	socialIconLineHeight: {
			// 		type: 'string',
			// 		default: 32,
			// 	},
			
			// 	socialIconShow: {
			// 		type: 'boolean',
			// 		default: true,
			// 	},
			// 	socialColor: {
			// 		type: 'boolean',
			// 		default: false,
			// 	},
			// 	socialIconColor: {
			// 		type: 'string',
			// 		default: '#fff',
			// 	},
			// 	socialIconBackgroundColor: {
			// 		type: 'string',
			// 		default: '#d34836',
			// 	},
			// 	socialIconBorderColor: {
			// 		type: 'string',
			// 		default: '',
			// 	},
			
			// 	hoverEffect: {
			// 		type: 'boolean',
			// 		default: true,
			// 	},
			
			// 	hoverBackgroundColor: {
			// 		type: 'string',
			// 		default: '',
			// 	},
			
			// 	hoverBackgroundOpacity: {
			// 		type: 'number',
			// 		default: '.1',
			// 	},
			// 	facebookLink: {
			// 		type: 'string',
			// 		source: 'attribute',
			// 		selector: 'a',
			// 		attribute: 'href',
			// 	},
			
			// 	twitterLink: {
			// 		type: 'string',
			// 		source: 'attribute',
			// 		selector: 'a',
			// 		attribute: 'href',
			// 	},
			// 	googleplusLink: {
			// 		type: 'string',
			// 		source: 'attribute',
			// 		selector: 'a',
			// 		attribute: 'href',
			// 	},
			// }
		},
		id: {
			type: "string",
			source: "attribute",
			selector: ".carousel.slide",
			attribute: "id"
		},
		testBackgroundColor: {
			type: 'string',
			// attribute: 'style',
			// selector: 'div.pb-team-member-background',
			default: '#0073a8',
			// property: 'background-color'
		},
    },
	edit: Edit,
	save: function(props) {
		const { 
			attributes: {
				teams,
				testBackgroundColor
			},
			setAttributes 
		} = props;
		console.log(props.attributes);
		return (
			<div 
			// style= {{ backgroundColor:testBackgroundColor}}
			>
				{
					teams.sort( ( a, b ) => a.index - b.index ).map( ( team, index ) => {
						return (
							<TeamMember key={ index } { ...{ setAttributes, ...props } } team={ team }/>
						)
					} )
				}
			</div>
		)
	}
	// save: function(props) {
	// 	const { teams } = props.attributes; // memberName in our block.
	// 	console.log("save teams", teams);
	// 	const id = props.attributes.id;
	// 	const teamsList = teams.sort( ( a, b ) => a.index - b.index ).map( ( team, index ) => {
	// 		const commonStyle = {
	// 			borderColor: team.socialIconBorderColor, color: team.socialIconColor,
	// 			backgroundColor: team.socialIconBackgroundColor,
	// 			width: team.socialIconWidth,
	// 			height: team.socialIconWidth,
	// 		};
	// 		const fbStyle = ( team.socialColor ) ? {
	// 			color: '#fff', backgroundColor: '#4267b2', width: team.socialIconWidth, height: team.socialIconWidth,
	// 		} : commonStyle;
	// 		const twitterStyle = ( team.socialColor ) ? {
	// 			color: '#fff', backgroundColor: '#1da1f2', width: team.socialIconWidth, height: team.socialIconWidth,
	// 		} : commonStyle;
	// 		const googleStyle = ( team.socialColor ) ? {
	// 			color: '#fff', backgroundColor: '#d34836', width: team.socialIconWidth, height: team.socialIconWidth,
	// 		} : commonStyle;
	// 		return (
	// 			<div className={ classnames(
	// 				props.className,
	// 				'pb-team-member',
	// 				'pb-team-member-background'
	// 			) }
	// 			 style={ {
	// 				color: team.memberNameColor,
	// 				backgroundColor: team.memberBackgroundColor,
	// 				borderRadius: team.memberBorderRadius,
	// 				margin: team.memberMargin,
	// 				padding: team.memberPadding,
	// 			} }
	// 			>
	// 				<div className="pb-team-info">
	// 					<h2 className=""> {team.memberName}</h2>
	// 					<p className="pb-team-member-designation"> {team.memberDesignation}</p>
	// 					<p className="pb-team-member-description"> {team.memberDescription}</p>
	// 					{/* { (team.socialIconShow ) ?
	// 						<div className="pb-team-social">
	// 							<ul>
	// 								<li> <a href={ team.facebookLink } style={ fbStyle }> <Dashicon icon="facebook-alt" />
	// 								</a> </li>
	// 								<li> <a href={ team.twitterLink } style={ twitterStyle }> <Dashicon icon="twitter" /> </a> </li>
	// 								<li> <a href={ team.googleplusLink }style={ googleStyle }> <Dashicon icon="googleplus" /> </a> </li>
	// 							</ul>
	// 						</div> : ''
	// 					} */}
					
	// 				</div>
	// 			 </div>
	// 		);
	// 	});
	// 	return  (
	// 		<div>
	// 			{teamsList}
	// 		</div>
	// 	)
	// }
});
