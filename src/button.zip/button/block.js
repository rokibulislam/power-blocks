//  import defaultButtonAttributes from './components/attribute';
import EditPbButton from './components/editbutton';
import PbButton from './components/button';
import './styles/style.scss';
import './styles/editor.scss';
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
registerBlockType( 'power-blocks/pbbutton', {
	title: __( 'Power Button', 'power-blocks' ),
	description: __( ' ', 'power-blocks' ),
	icon: 'format-status',
	category: 'power-blocks',
	keywords: [
		__( 'Button', 'power-blocks' ),
	],
	attributes: {
		id: {
			source: 'attribute',
			attribute: 'id',
		},
		items: {
			type: 'array',
			default: [
				//  defaultButtonAttributes
				// { 
					// buttonText: 'NEW Button',
					// buttonUrl: '',
					// borderRadius: '0',
					// buttonSize: '',
					// buttonBackground: '#000',
					// borderColor: '#000',
					// hoverColor: '#dd0',
					// buttonTextColor: '#fff',
					// buttonTarget: 'false',
					// buttonAlignment: 'left',
				// }
			]		
		}
	},

	styles: [

	],

	edit: EditPbButton,
	// edit: ( props ) => {
	// 	return (
	// 		<section className={ props.className }>
	// 			hello
	// 		</section>
	// 	);
	// },
	save: PbButton,
	// save: function( props ) {
	// 	//Setup the attributes
	// 	// const {
	// 	// 	attributes: {
	// 	// 		items,
	// 	// 	},
	// 	// } = props;

	// 	// const buttons = items.map( ( item, index ) => {
	// 	// 	return (
	// 	// 		<a href={ item.buttonUrl } key={ index }
	// 	// 			style={ {
	// 	// 				color: item.buttonTextColor,
	// 	// 				backgroundColor: item.buttonBackground,
	// 	// 				borderRadius: item.borderRadius,
	// 	// 			} } target={ item.buttonTarget ? '_blank' : '_self' } >
	// 	// 			{ item.buttonText }
	// 	// 		</a>
	// 	// 	)
	// 	// } );
	// 	return (
	// 		<div>
	// 			buttonjaja
	// 		</div>
	// 	)
	// },
} );
