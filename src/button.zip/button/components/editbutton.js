const { __ } = wp.i18n;
const { Component, Fragment } = wp.element;
const { AlignmentToolbar, BlockControls } = wp.editor;
const { Toolbar, Button } = wp.components;
import Inspector from './inspector';
import PbButton from './button';
export default class EditPbButton extends Component {

	state = {
		selected: 0,
	}

	clickHandler = ( index ) => {
		this.setState( ( state, props ) => ( {
			selected: index,
		} ) )
	}

	render() {
		const {
			attributes: {
				items,
				design,
			},
			setAttributes,
			isSelected,
			className
		} = this.props;

		// console.log( this.state.select + 'editbutton' );

		return (
			<Fragment>
				<BlockControls key="controls">
					<AlignmentToolbar
						value={ '' }
						onChange={ ( value ) => setAttributes( { '': value } ) }
					/>
					<Toolbar>
						<Button
							className={ 'button button-primary power-add-item-wrapper' }
							onClick={ ( event ) => {
								return setAttributes( { 
									// items: items.push({
									// 	buttonText: 'NEW Button',
									// 	buttonUrl: '',
									// 	borderRadius: '0',
									// 	buttonSize: '',
									// 	buttonBackground: '#000',
									// 	borderColor: '#000',
									// 	hoverColor: '#dd0',
									// 	buttonTextColor: '#fff',
									// 	buttonTarget: 'false',
									// 	buttonAlignment: 'left',
									// })
									items: items.concat( [
										{
											buttonText: 'NEW Button',
											buttonUrl: '',
											borderRadius: '0',
											buttonSize: '',
											buttonBackground: '#000',
											borderColor: '#000',
											hoverColor: '#dd0',
											buttonTextColor: '#fff',
											buttonTarget: 'false',
											buttonAlignment: 'left',
										// buttonText: {
										// 	type: 'string',
										// 	selector: '.pb_button',
										// 	default: '',
										// },
										// buttonUrl: {
										// 	type: 'string',
										// 	default: '',
										// 	source: 'attribute',
										// 	selector: 'a',
										// 	attribute: 'href',
										// },
										// borderRadius: {
										// 	type: 'number',
										// 	default: 0,
										// },
										// buttonSize: {
										// 	type: 'number',
										// 	default: 0,
										// },
										// buttonBackground: {
										// 	type: 'string',
										// 	default: '#000',
										// },
										// borderColor: {
										// 	type: 'string',
										// 	default: '#000',
										// },
										// hoverColor: {
										// 	type: 'string',
										// 	default: '#fff',
										// },
										// buttonTextColor: {
										// 	type: 'string',
										// 	default: '#fff',
										// },
										// buttonTarget: {
										// 	type: 'boolean',
										// 	default: false,
										// },
										// buttonAlignment: {
										// 	type: 'string',
										// 	default: 'center',
										// },
										}
								] 
							)
							} );
						}
					}
						>
							{ __( 'Add Item' + this.state.selected ) }
						</Button>

						<Button onClick={ ( e ) => { } }> Remove Button	</Button>
					</Toolbar>
				</BlockControls>
				<Inspector { ...{ setAttributes, ...this.props } } state={ this.state } />
				<PbButton { ...this.props } key=" " state={ this.state } clickHandler={ this.clickHandler }></PbButton>
			</Fragment>
		);
	}
}