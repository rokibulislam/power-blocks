const { Component } = wp.element;
const { __ } = wp.i18n;
const { RichText } = wp.editor;
import classnames from 'classnames';

export default class PbButton extends Component { 

	faqsUpdate( index, key, newValue ) {
		const self = this;
		const items = self.props.attributes.items;
		return items.map( function( item, currIndex ) {
			if ( index == currIndex ) {
				item[ key ] = newValue;
			}
			return item;
		} );
	}

	render() {
		const {
			attributes: {
				// buttonText,
				// buttonUrl,
				// borderRadius,
				// buttonSize,
				// buttonBackground,
				// borderColor,
				// hoverColor,
				// buttonTextColor,
				// buttonTarget,
				// buttonAlignment,
				items,
			},
			setAttributes,
			state,
			clickHandler,
		} = this.props;
		// const onChangeBackgroundColor = value => setAttributes( { memberBackgroundColor: value } );
		/**
         * Create items ui
         */
		const rows = items.map( ( item, index ) => {
			return (
				<div key={ index } data-id={ index } onClick={ () => {  clickHandler( index ) } } >

					<p
						style={ {
							color: item.buttonTextColor,
							backgroundColor: item.buttonBackground,
							borderRadius: item.borderRadius,
						} }>
						<RichText
							className={ classnames(
								this.props.className,
								'pb_button'
							) }
							tagName="span"
							value={ item.buttonText }
							placeholder={ __( '', 'power-blocks' ) }
							onChange={ ( value ) => setAttributes( {
								// item: this.faqsUpdate( state.selected, 'buttonText', value ),
							} ) }
						/>
					</p>
				</div>
			)
		} );
		return (
			<div>
				{ rows }
			</div>
		);
	}
}
